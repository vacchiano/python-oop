# practising importing modules
# importing from parent.py
import parent

